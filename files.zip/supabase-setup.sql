-- Rode isto no Supabase: Project → SQL Editor → New query → cole tudo → Run

create table if not exists app_data (
  key text primary key,
  value jsonb,
  updated_at timestamptz default now()
);

-- Habilita Row Level Security (obrigatório no Supabase)
alter table app_data enable row level security;

-- Libera leitura e escrita usando a chave "anon" (a que fica no HTML).
-- Isso é seguro o suficiente para um painel pessoal de uso único,
-- mas lembre-se: quem tiver a URL + a anon key consegue ler/escrever
-- nessa tabela diretamente pela API do Supabase, sem passar pela tela
-- de login do painel (a tela de login é só uma trava de interface,
-- não uma autenticação de verdade).
create policy "allow all access" on app_data
  for all
  using (true)
  with check (true);
